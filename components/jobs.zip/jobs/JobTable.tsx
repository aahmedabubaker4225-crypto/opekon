import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui";

import JobRow from "./JobRow";

export type JobStatus =
  | "lead"
  | "scheduled"
  | "in_progress"
  | "completed"
  | "cancelled";

export type Job = {
  id: string;
  customerId: string;
  customerName: string;
  title: string;
  description?: string | null;
  address?: string | null;
  status: JobStatus;
  createdAt?: string;
};

type JobTableProps = {
  jobs: Job[];
};

export default function JobTable({
  jobs,
}: JobTableProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Job</TableHead>
          <TableHead>Customer</TableHead>
          <TableHead>Address</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>

      <TableBody>
        {jobs.map((job) => (
          <JobRow
            key={job.id}
            job={job}
          />
        ))}
      </TableBody>
    </Table>
  );
}