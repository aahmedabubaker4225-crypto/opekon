"use client";

import { useMemo, useState } from "react";
import {
  Button,
  EmptyState,
  Modal,
  PageHeader,
} from "@/components/ui";

import JobForm, {
  type JobFormData,
} from "./JobForm";
import JobSearch from "./JobSearch";
import JobStats from "./JobStats";
import JobTable, {
  type Job,
} from "./JobTable";

type CustomerOption = {
  id: string;
  name: string;
};

type JobClientProps = {
  initialJobs: Job[];
  customers: CustomerOption[];
};

export default function JobsClient({
  initialJobs,
  customers,
}: JobClientProps) {
  const [jobs, setJobs] =
    useState<Job[]>(initialJobs);

  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] =
    useState(false);

  const filteredJobs = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return jobs;
    }

    return jobs.filter((job) =>
      [
        job.title,
        job.description,
        job.customerName,
        job.address,
        job.status,
      ].some((value) =>
        value?.toLowerCase().includes(query)
      )
    );
  }, [jobs, search]);

  function handleJobCreated(
    jobData: JobFormData
  ) {
    const customer = customers.find(
      (customer) =>
        customer.id === jobData.customerId
    );

    const newJob: Job = {
      id: crypto.randomUUID(),
      customerId: jobData.customerId,
      customerName:
        customer?.name ?? "Unknown Customer",
      title: jobData.title,
      description: jobData.description,
      address: jobData.address,
      status: jobData.status,
      createdAt: new Date().toISOString(),
    };

    setJobs((currentJobs) => [
      newJob,
      ...currentJobs,
    ]);

    setIsModalOpen(false);
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Jobs"
        description="Manage leads, scheduled work, active jobs, and completed projects."
        actions={
          <Button
            type="button"
            onClick={() => setIsModalOpen(true)}
            disabled={customers.length === 0}
          >
            New Job
          </Button>
        }
      />

      <JobStats jobs={jobs} />

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <JobSearch
          value={search}
          onChange={setSearch}
        />

        <p className="text-sm text-zinc-400">
          {filteredJobs.length}{" "}
          {filteredJobs.length === 1
            ? "job"
            : "jobs"}
        </p>
      </div>

      {customers.length === 0 ? (
        <EmptyState
          title="Add a customer first"
          description="Every job must belong to a customer. Create a customer before adding your first job."
        />
      ) : filteredJobs.length > 0 ? (
        <JobTable jobs={filteredJobs} />
      ) : (
        <EmptyState
          title={
            search
              ? "No jobs found"
              : "No jobs yet"
          }
          description={
            search
              ? "Try searching by job title, customer, address, or status."
              : "Create your first job to start tracking work."
          }
          action={
            !search ? (
              <Button
                type="button"
                onClick={() =>
                  setIsModalOpen(true)
                }
              >
                Add Job
              </Button>
            ) : undefined
          }
        />
      )}

      <Modal
        open={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="New Job"
      >
        <JobForm
          customers={customers}
          onSubmit={handleJobCreated}
        />
      </Modal>
    </div>
  );
}