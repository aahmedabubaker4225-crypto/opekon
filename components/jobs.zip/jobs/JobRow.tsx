import {
  Badge,
  TableCell,
  TableRow,
} from "@/components/ui";

import type {
  Job,
  JobStatus,
} from "./JobTable";

type JobRowProps = {
  job: Job;
};

function getStatusVariant(
  status: JobStatus
):
  | "default"
  | "success"
  | "warning"
  | "danger" {
  switch (status) {
    case "completed":
      return "success";

    case "scheduled":
    case "in_progress":
      return "warning";

    case "cancelled":
      return "danger";

    default:
      return "default";
  }
}

function formatStatus(status: JobStatus) {
  return status
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) =>
      letter.toUpperCase()
    );
}

export default function JobRow({
  job,
}: JobRowProps) {
  return (
    <TableRow>
      <TableCell>
        <p className="font-medium text-white">
          {job.title}
        </p>

        {job.description && (
          <p className="mt-1 line-clamp-1 text-sm text-zinc-400">
            {job.description}
          </p>
        )}
      </TableCell>

      <TableCell>
        {job.customerName}
      </TableCell>

      <TableCell>
        {job.address || "—"}
      </TableCell>

      <TableCell>
        <Badge
          variant={getStatusVariant(job.status)}
        >
          {formatStatus(job.status)}
        </Badge>
      </TableCell>
    </TableRow>
  );
}