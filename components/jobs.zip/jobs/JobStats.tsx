import { StatCard } from "@/components/ui";
import type { Job } from "./JobTable";

type JobStatsProps = {
  jobs: Job[];
};

export default function JobStats({
  jobs,
}: JobStatsProps) {
  const totalJobs = jobs.length;

  const leads = jobs.filter(
    (job) => job.status === "lead"
  ).length;

  const scheduled = jobs.filter(
    (job) => job.status === "scheduled"
  ).length;

  const inProgress = jobs.filter(
    (job) => job.status === "in_progress"
  ).length;

  const completed = jobs.filter(
    (job) => job.status === "completed"
  ).length;

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard
        label="Total Jobs"
        value={totalJobs}
      />

      <StatCard
        label="Leads"
        value={leads}
      />

      <StatCard
        label="Scheduled"
        value={scheduled}
      />

      <StatCard
        label="Completed"
        value={completed}
      />
    </div>
  );
}