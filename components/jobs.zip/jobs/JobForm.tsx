"use client";

import { useState } from "react";
import {
  Button,
  Card,
  Input,
  Select,
  Textarea,
} from "@/components/ui";

import type { JobStatus } from "./JobTable";

export type JobFormData = {
  customerId: string;
  title: string;
  description: string;
  address: string;
  status: JobStatus;
};

type CustomerOption = {
  id: string;
  name: string;
};

type JobFormProps = {
  customers: CustomerOption[];
  initialValues?: Partial<JobFormData>;
  submitLabel?: string;
  onSubmit?: (
    job: JobFormData
  ) => void | Promise<void>;
};

export default function JobForm({
  customers,
  initialValues,
  submitLabel = "Save Job",
  onSubmit,
}: JobFormProps) {
  const [customerId, setCustomerId] =
    useState(initialValues?.customerId ?? "");

  const [title, setTitle] = useState(
    initialValues?.title ?? ""
  );

  const [description, setDescription] =
    useState(initialValues?.description ?? "");

  const [address, setAddress] = useState(
    initialValues?.address ?? ""
  );

  const [status, setStatus] =
    useState<JobStatus>(
      initialValues?.status ?? "lead"
    );

  const [isSubmitting, setIsSubmitting] =
    useState(false);

  async function handleSubmit(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    if (!customerId || !title.trim()) {
      return;
    }

    try {
      setIsSubmitting(true);

      await onSubmit?.({
        customerId,
        title: title.trim(),
        description: description.trim(),
        address: address.trim(),
        status,
      });

      if (!initialValues) {
        setCustomerId("");
        setTitle("");
        setDescription("");
        setAddress("");
        setStatus("lead");
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Card className="max-w-2xl">
      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >
        <Select
          label="Customer"
          value={customerId}
          onChange={(event) =>
            setCustomerId(event.target.value)
          }
          required
        >
          <option value="">
            Select a customer
          </option>

          {customers.map((customer) => (
            <option
              key={customer.id}
              value={customer.id}
            >
              {customer.name}
            </option>
          ))}
        </Select>

        <Input
          label="Job Title"
          placeholder="Garage cleanout"
          value={title}
          onChange={(event) =>
            setTitle(event.target.value)
          }
          required
        />

        <Textarea
          label="Description"
          placeholder="Describe the work that needs to be completed."
          value={description}
          onChange={(event) =>
            setDescription(event.target.value)
          }
          rows={4}
        />

        <Input
          label="Job Address"
          placeholder="123 Main Street, Calgary"
          value={address}
          onChange={(event) =>
            setAddress(event.target.value)
          }
        />

        <Select
          label="Status"
          value={status}
          onChange={(event) =>
            setStatus(
              event.target.value as JobStatus
            )
          }
        >
          <option value="lead">Lead</option>
          <option value="scheduled">
            Scheduled
          </option>
          <option value="in_progress">
            In Progress
          </option>
          <option value="completed">
            Completed
          </option>
          <option value="cancelled">
            Cancelled
          </option>
        </Select>

        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={
              isSubmitting ||
              !customerId ||
              !title.trim()
            }
          >
            {isSubmitting
              ? "Saving..."
              : submitLabel}
          </Button>
        </div>
      </form>
    </Card>
  );
}