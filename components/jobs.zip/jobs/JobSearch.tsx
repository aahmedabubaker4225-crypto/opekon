"use client";

import { Input } from "@/components/ui";

type JobSearchProps = {
  value: string;
  onChange: (value: string) => void;
};

export default function JobSearch({
  value,
  onChange,
}: JobSearchProps) {
  return (
    <div className="w-full max-w-md">
      <Input
        placeholder="Search jobs..."
        value={value}
        onChange={(event) =>
          onChange(event.target.value)
        }
      />
    </div>
  );
}